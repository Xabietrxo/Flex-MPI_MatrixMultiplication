#!/bin/bash
#set -x

# Check there are two parameters and the second is a number (-gt gets error otherwise)
if [ $# -eq 3 ] && [ "$2" -gt "0" ] 2>/dev/null && [ "$3" -gt "0" ] 2>/dev/null; then
    echo "Everything correct, do nothing" > /dev/null
else 
    echo "Usage: compose_file_name num_replicas  num_cores_per_replica"
    exit 1
fi

# set parameter variables
COMPOSE_FILE_BASENAME=$1
NUM_NODES=$2
NUM_CORES=$3

# set file variables
BASEDIR="$(dirname -- $0)"
TEMP_FILE="$BASEDIR/.tmp-${RANDOM}"
NODE_TEMPLATE=${BASEDIR}/${COMPOSE_FILE_BASENAME}.template
NODE_HEADER=${BASEDIR}/${COMPOSE_FILE_BASENAME}.header
COMPOSE_FILE=${BASEDIR}/${COMPOSE_FILE_BASENAME}.yml

# Check header file exist
if [ ! -f ${NODE_HEADER} ]; then
    echo "ERROR: ${NODE_HEADER} does not exist"
    exit 1
fi

# Check template file exist
if [ ! -f ${NODE_TEMPLATE} ]; then
    echo "ERROR: ${NODE_TEMPLATE} does not exist"
    exit 1
fi

# Write header on temp file
cat ${NODE_HEADER} > ${TEMP_FILE}
echo >> ${TEMP_FILE}

# loop to write each node on temp file
for NODE in $(seq 1 ${NUM_NODES}); do
    sed "s/REPLACE_NODE_NUM/${NODE}/g" < ${NODE_TEMPLATE} | sed "s/REPLACE_NUM_CORES/${NUM_CORES}/g" >> ${TEMP_FILE}
    echo >> ${TEMP_FILE}
done

# Backup existing compose file, replace it, and erase temp file
if [ -f ${COMPOSE_FILE} ]; then
    mv -f ${COMPOSE_FILE} ${COMPOSE_FILE}.old
fi
mv -f ${TEMP_FILE} ${COMPOSE_FILE}



