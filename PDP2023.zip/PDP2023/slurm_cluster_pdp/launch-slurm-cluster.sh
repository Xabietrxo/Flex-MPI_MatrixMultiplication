#!/bin/bash
#set -x

# define usage mesagge
usage() { echo "Usage: $0 [-n <number of nodes>] [-c <cores per node>] [-b <compose file basename>] [-d] " 1>&2; exit 1; }

# set inital paremeter variables
FORCE_CLEAN=0
NUMNODES=1
NUMCORES=1
COMPOSE_FILE_BASENAME=docker-compose-slurm
# parse parameters
while getopts ":n:c:d" o; do
    case "${o}" in
        n)
            NUMNODES=${OPTARG}
            ((NUMNODES > 0 )) || usage
            ;;
        c)
            NUMCORES=${OPTARG}
            ((NUMCORES > 0 )) || usage
            ;;
        b)
            COMPOSE_FILE_BASENAME=${OPTARG}
            ;;
        d)
            FORCE_CLEAN=1
            ;;
       *)
            usage
            ;;
    esac
done
shift $((OPTIND-1))

# other variables
BASEDIR="$(dirname -- $0)"
COMPOSE_FILE=${BASEDIR}/${COMPOSE_FILE_BASENAME}.yml

# Remove existing Docker cluster
docker compose  -p slurm  down --remove-orphans --rmi local

#remove and recreare shared homes
rm -rf ${BASEDIR}/shared/shared-user
mkdir -p ${BASEDIR}/shared/shared-user
rm -rf ${BASEDIR}/shared/shared-coord
mkdir -p ${BASEDIR}/shared/shared-coord
rm -rf ${BASEDIR}/shared/shared-admin
mkdir -p ${BASEDIR}/shared/shared-admin

#create docker compose file
${BASEDIR}/create-docker-compose-file.sh ${COMPOSE_FILE_BASENAME} ${NUMNODES} ${NUMCORES}

#build docker image
if [ "${FORCE_CLEAN}" == "1" ]; then
    docker builder prune
    docker compose  -p slurm -f ${COMPOSE_FILE} build --no-cache
fi
#launch docker container
docker compose  -p slurm -f ${COMPOSE_FILE} up -d
