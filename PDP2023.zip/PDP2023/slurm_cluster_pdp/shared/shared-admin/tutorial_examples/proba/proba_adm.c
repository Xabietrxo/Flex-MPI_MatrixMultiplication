/**
 *
 *    Proba
 *
 */
#include <stdio.h>
#include <mpi.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <unistd.h>
#include <empi.h>
#include <stdbool.h>

#define ROWS 5
#define COLS 10

void generateRandomMatrix(int matrix[ROWS*COLS]) {
    int i, j;

    for (i = 0; i < ROWS; i++) {
        for (j = 0; j < COLS; j++) {
            matrix[COLS*i+j] = rand() % 100;  // Random numbers between 0-99
        }
    }
}

void printMatrix(int matrix[ROWS*COLS]) {
    int i, j;

    for (i = 0; i < ROWS; i++) {
        for (j = 0; j < COLS; j++) {
            printf("%3d ", matrix[COLS*i+j]);
        }
        printf("\n");
    }
}

int main (int argc, char *argv[])
{
    int it=0;
    int itmax=ROWS*COLS;

    int *matrix1 = NULL;
    int *matrix2 = NULL;
    int result[ROWS*COLS];

    int *buffer = NULL;

    bool bidali = false;

    MPI_Datatype intercalate_type;                                  //A type to gather intercalated

    matrix1 = (int *)malloc(ROWS * COLS * sizeof(int));
    matrix2 = (int *)malloc(ROWS * COLS * sizeof(int));

    // init MPI and get world_rank and world_size
    int world_rank, world_size;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(ADM_COMM_WORLD, &world_rank);
    MPI_Comm_size(ADM_COMM_WORLD, &world_size);

    // get processor name
    int len;
    char mpi_name[100];
    MPI_Get_processor_name(mpi_name, &len);

    int dim = ROWS*COLS;

    printf ("Rank(%d/%d): Start\n", world_rank, world_size);    

    if (world_rank == 0) {
        srand(time(NULL));  // Initiate random seed
        generateRandomMatrix(matrix1);
        generateRandomMatrix(matrix2);
        buffer = (int *)malloc(ROWS * COLS * sizeof(int));
    }

    MPI_Bcast(matrix1, dim, MPI_INT, 0, ADM_COMM_WORLD);    //Broadcast both matrix
    MPI_Bcast(matrix2, dim, MPI_INT, 0, ADM_COMM_WORLD);

    

    // get all processors names
    char local_name[128];
    char global_name[128];
    sprintf(local_name, "%s,", mpi_name);
    
    // shared processors names
    bzero(global_name,128);
    MPI_Allgather(local_name, strlen(local_name), MPI_CHAR, global_name, strlen(local_name), MPI_CHAR, ADM_COMM_WORLD);
                            
    // get process type
    int proctype;
    ADM_GetSysAttributesInt ("ADM_GLOBAL_PROCESS_TYPE", &proctype);

    // if process is native
    if (proctype == ADM_NATIVE) {
        
        printf ("Rank(%d/%d): Process native\n", world_rank, world_size);
        
    // if process is spawned
    } else {

        printf ("Rank(%d/%d): Process spawned\n", world_rank, world_size);
    }
    
    /* set max number of iterations */
    ADM_RegisterSysAttributesInt ("ADM_GLOBAL_MAX_ITERATION", &itmax);

    /* get actual iteration for new added processes*/
    ADM_GetSysAttributesInt ("ADM_GLOBAL_ITERATION", &it);

    /* starting monitoring service */
    ADM_MonitoringService (ADM_SERVICE_START);

    // init last world zize
    int last_world_size = world_size;
    
    // start loop
    for (; it < itmax; it ++) {
        
        //Select hints on specific iterations
        int procs_hint = 0;
        int excl_nodes_hint = 0;
        if ( (it == 2*(itmax/10)) || (it == 4*(itmax/10)) ){
            procs_hint = 2;
            excl_nodes_hint = 0;
            ADM_RegisterSysAttributesInt ("ADM_GLOBAL_HINT_NUM_PROCESS", &procs_hint);
            ADM_RegisterSysAttributesInt ("ADM_GLOBAL_HINT_EXCL_NODES", &excl_nodes_hint);
        } else if ( (it == 6*(itmax/10)) || (it == 8*(itmax/10)) ){
            procs_hint = -2;
            excl_nodes_hint = 0;
            if (world_rank >= world_size+procs_hint)
            {
                bidali = true;
            }
            ADM_RegisterSysAttributesInt ("ADM_GLOBAL_HINT_NUM_PROCESS", &procs_hint);
            ADM_RegisterSysAttributesInt ("ADM_GLOBAL_HINT_EXCL_NODES", &excl_nodes_hint);
        }else if ((it == 2*(itmax/10)-1) || (it == 4*(itmax/10)-1) || (it == 6*(itmax/10)-1) || (it == 8*(itmax/10)-1))
        {
            MPI_Type_vector(it/world_size, 1, world_size, MPI_INT, &intercalate_type);
            MPI_Type_commit(&intercalate_type);
            if (world_rank!=0)
            {
                MPI_Send(&result[world_rank], 1, intercalate_type, 0, 0, ADM_COMM_WORLD);
                printf("Rank (%d/%d): Iteration= %d,----------Bidalita----------\n", world_rank, world_size, it);
            }
            if (world_rank==0)
            {
                for (int i = 1; i < last_world_size; i++)
                {
                    MPI_Recv(&buffer[i], 1, intercalate_type, i, 0, ADM_COMM_WORLD, MPI_STATUS_IGNORE);
                    printf("Rank (%d/%d): Iteration= %d,----------%d prozesutik jaso du----------\n", world_rank, world_size, it, i);
                }
            }
        }
        
        // update message if new spawned processes
        if (last_world_size != world_size) {

            

            if (last_world_size < world_size)
            {
                MPI_Bcast(matrix1, dim, MPI_INT, 0, ADM_COMM_WORLD);    //Broadcast both matrix
                MPI_Bcast(matrix2, dim, MPI_INT, 0, ADM_COMM_WORLD);
            }else if(last_world_size > world_size){
                printf("Rank (%d/%d): Iteration= %d,----------Hemen sartu da----------\n", world_rank, world_size, it);
            }

            
            

            // shared processors names
            bzero(global_name,128);
            MPI_Allgather(local_name, strlen(local_name), MPI_CHAR, global_name, strlen(local_name), MPI_CHAR, ADM_COMM_WORLD);

            last_world_size = world_size;
        }
        
        /* start malelability region */
        ADM_MalleableRegion (ADM_SERVICE_START);
        
        printf("Rank (%d/%d): Iteration= %d, Hello world from: \n\t\t%s\n", world_rank, world_size, it, global_name);

        // simulate compute
        if (it%world_size == world_rank)        //Divide workload in processes
        {
            result[it] = matrix1[it] + matrix2[it];
        }
        sleep(1);
/*
        if (bidali)
        {
            MPI_Send(&result[world_rank], 1, intercalate_type, 0, 0, ADM_COMM_WORLD);
            printf("Rank (%d/%d): Iteration= %d,----------Bidalita----------\n", world_rank, world_size, it);
        }
*/    
        // update the iteration value
        ADM_RegisterSysAttributesInt ("ADM_GLOBAL_ITERATION", &it);
        
        // ending malleable region
        int status;
        status = ADM_MalleableRegion (ADM_SERVICE_STOP);
        
        if (status == ADM_ACTIVE) {
            // updata world_rank and size
            MPI_Comm_rank(ADM_COMM_WORLD, &world_rank);
            MPI_Comm_size(ADM_COMM_WORLD, &world_size);
        } else {
            // end the process
            break;
        }
    }

    /* ending monitoring service */
    ADM_MonitoringService (ADM_SERVICE_STOP);
    
    printf("Rank (%d/%d): End of loop \n", world_rank, world_size);

    MPI_Finalize();

    printf("Rank (%d/%d): End of process %d\n", world_rank, world_size, world_rank);
    if (world_rank == 0) {

        printf("Matrix 1:\n");
        printMatrix(matrix1);

        printf("\nMatrix 2:\n");
        printMatrix(matrix2);

        printf("\nSum result:\n");
        printMatrix(result);

        free(buffer);

        printf("Rank (%d/%d): End of Application\n", world_rank, world_size);
    }

    return 0;
}
