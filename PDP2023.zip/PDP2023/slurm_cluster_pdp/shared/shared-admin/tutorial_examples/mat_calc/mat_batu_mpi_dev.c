#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <mpi.h>

#define FILAS 15
#define COLUMNAS 15
#define GORRI "\x1B[31m"
#define BERDE "\x1B[32m"
#define HORI "\x1B[33m"
#define URDIN "\x1B[34m"
#define TXURI "\x1B[0m"
void generarMatrizAleatoria(int matriz[FILAS*COLUMNAS]) {
    int i, j;

    for (i = 0; i < FILAS; i++) {
        for (j = 0; j < COLUMNAS; j++) {
            matriz[COLUMNAS*i+j] = rand() % 100;  // Generar números aleatorios entre 0 y 99
        }
    }
}
/*
void sumarMatrices(int matriz1[FILAS][COLUMNAS], int matriz2[FILAS][COLUMNAS], int resultado[FILAS][COLUMNAS]) {
    int i, j;

    for (i = 0; i < FILAS; i++) {
        for (j = 0; j < COLUMNAS; j++) {
            resultado[i][j] = matriz1[i][j] + matriz2[i][j];
        }
    }
}
*/
void imprimirMatriz(int matriz[FILAS*COLUMNAS]) {
    int i, j;

    for (i = 0; i < FILAS; i++) {
        for (j = 0; j < COLUMNAS; j++) {
            if((COLUMNAS*i+j)%4==0){
                printf("0/%d:", COLUMNAS*i+j);
            }else if((COLUMNAS*i+j)%4==1){
                printf("1/%d:", COLUMNAS*i+j);
            }else if((COLUMNAS*i+j)%4==2){
                printf("2/%d:", COLUMNAS*i+j);
            }else{
                printf("3/%d:", COLUMNAS*i+j);
            }
            printf("%3d ", matriz[COLUMNAS*i+j]);
        }
        printf("\n");
    }
}

int main(int argc, char *argv[]) {

    int it=0;
    int itmax=FILAS*COLUMNAS;
    int *recvcounts = NULL, *displs = NULL;
    int lag=0;

    int matriz1[FILAS*COLUMNAS];
    int matriz2[FILAS*COLUMNAS];
    int resultado[FILAS*COLUMNAS];

    int rank, size;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
/*
    if (size != 1 && size != FILAS) {
        if (rank == 0) {
            printf("El número de procesos debe ser 1 o igual al número de filas de la matriz.\n");
        }
        MPI_Finalize();
        return 0;
    }
*/
    if (rank == 0) {
        srand(time(NULL));  // Inicializar la semilla aleatoria
        generarMatrizAleatoria(matriz1);
        generarMatrizAleatoria(matriz2);
        printf("Prozesu kopurua:%d\n\n", size);
    }

    MPI_Bcast(matriz1, FILAS * COLUMNAS, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(matriz2, FILAS * COLUMNAS, MPI_INT, 0, MPI_COMM_WORLD);

//    int inicio = ((FILAS*COLUMNAS) / size) * rank;
//    int fin = inicio+(FILAS*COLUMNAS)/size;
    int local_count = 0;

    for (; it < itmax; it++)
    {
        if (it%size == rank)
        {
            resultado[it] = matriz1[it] + matriz2[it];
            local_count++;
        }else{
            resultado[it] = 0;
        }
    }
/*
    for (int i = inicio; i < fin; i++) {
        resultado[i] = matriz1[i] + matriz2[i];
    }
*/
    int *buffer = NULL;
    if (rank == 0) {
        buffer = (int *)malloc(FILAS * COLUMNAS * sizeof(int));
    }

    recvcounts = (int*)malloc(size * sizeof(int));
    displs = (int*)malloc(size * sizeof(int));


//    MPI_Allgather(&local_count, 1, MPI_INT, recvcounts, 1, MPI_INT, MPI_COMM_WORLD);
    for(int i=0; i<size; i++){
//        displs[i] = displs[i-1] + recvcounts[i-1];
        recvcounts[i] = 1;
        displs[i] = i;
    }


    if(rank==1){
        sleep(10);
    }else if(rank==2){
        sleep(20);
    }else if(rank==3){
        sleep(30);
    }
    printf("RANK:%d-------------------------\n", rank);
    for(int j=0; j<FILAS*COLUMNAS; j++){
        printf("%d:%d ", j, resultado[j]);
    }
    printf("\n\n");

//    for (int k=0; k<4; k++){
//        printf("RANK:%d------------>recvcounts=%d------------------>displs=%d", rank, recvcounts[k], displs[k]);
//    }
//    printf("Rank:%d======>local_count:%d     \n\n", rank, local_count);

    printf("Rank %d------------------>Datatype sortzera.\n\n", rank);

        MPI_Datatype intercalado_type;
        MPI_Type_vector(56, 1, size, MPI_INT, &intercalado_type);
        MPI_Type_commit(&intercalado_type);
//        MPI_Gatherv(&resultado[rank], 1, intercalado_type, buffer, recvcounts, displs, intercalado_type, 0, MPI_COMM_WORLD);

    printf("Rank %d------------------>Datatype sortuta.\n\n", rank);

    if (rank!=0){
        MPI_Send(&resultado[rank], 1, intercalado_type, 0, 0, MPI_COMM_WORLD);
    }
    if(rank==0){
        for(int i=1; i<size; i++){
            MPI_Recv(&buffer[i], 1, intercalado_type, i, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }
    }

    printf("Rank %d------------------>Datuak elkarri bidalita.\n\n", rank);


    sleep(10);

    if (rank == 0) {
        printf("Matriz 1:\n");
        imprimirMatriz(matriz1);

        printf("\nMatriz 2:\n");
        imprimirMatriz(matriz2);

        printf("\nResultado de la suma:\n");
        imprimirMatriz(buffer);

        free(buffer);
    }

    MPI_Finalize();
    return 0;
}
