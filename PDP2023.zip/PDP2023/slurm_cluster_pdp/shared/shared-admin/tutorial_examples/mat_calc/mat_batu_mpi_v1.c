#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <mpi.h>

#define FILAS 20
#define COLUMNAS 20

void generarMatrizAleatoria(int matriz[FILAS*COLUMNAS]) {
    int i, j;

    for (i = 0; i < FILAS; i++) {
        for (j = 0; j < COLUMNAS; j++) {
            matriz[COLUMNAS*i+j] = rand() % 100;  // Generar números aleatorios entre 0 y 99
        }
    }
}
/*
void sumarMatrices(int matriz1[FILAS][COLUMNAS], int matriz2[FILAS][COLUMNAS], int resultado[FILAS][COLUMNAS]) {
    int i, j;

    for (i = 0; i < FILAS; i++) {
        for (j = 0; j < COLUMNAS; j++) {
            resultado[i][j] = matriz1[i][j] + matriz2[i][j];
        }
    }
}
*/
void imprimirMatriz(int matriz[FILAS*COLUMNAS]) {
    int i, j;

    for (i = 0; i < FILAS; i++) {
        for (j = 0; j < COLUMNAS; j++) {
            printf("%3d ", matriz[COLUMNAS*i+j]);
        }
        printf("\n");
    }
}

int main(int argc, char *argv[]) {
    int matriz1[FILAS*COLUMNAS];
    int matriz2[FILAS*COLUMNAS];
    int resultado[FILAS*COLUMNAS];

    int rank, size;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
/*
    if (size != 1 && size != FILAS) {
        if (rank == 0) {
            printf("El número de procesos debe ser 1 o igual al número de filas de la matriz.\n");
        }
        MPI_Finalize();
        return 0;
    }
*/
    if (rank == 0) {
        srand(time(NULL));  // Inicializar la semilla aleatoria
        generarMatrizAleatoria(matriz1);
        generarMatrizAleatoria(matriz2);
    }

    MPI_Bcast(matriz1, FILAS * COLUMNAS, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(matriz2, FILAS * COLUMNAS, MPI_INT, 0, MPI_COMM_WORLD);

    int inicio = ((FILAS*COLUMNAS) / size) * rank;
    int fin = inicio+(FILAS*COLUMNAS)/size;

    for (int i = inicio; i < fin; i++) {
        resultado[i] = matriz1[i] + matriz2[i];
    }

    int *buffer = NULL;
    if (rank == 0) {
        buffer = (int *)malloc(FILAS * COLUMNAS * sizeof(int));
    }

    MPI_Gather(resultado + inicio, fin - inicio, MPI_INT, buffer, fin - inicio, MPI_INT, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        printf("Matriz 1:\n");
        imprimirMatriz(matriz1);

        printf("\nMatriz 2:\n");
        imprimirMatriz(matriz2);

        printf("\nResultado de la suma:\n");
        imprimirMatriz(buffer);

        free(buffer);
    }

    MPI_Finalize();
    return 0;
}
