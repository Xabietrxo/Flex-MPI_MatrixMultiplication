/**
 *
 *    Hello world
 *
 */
#include <stdio.h>
#include <mpi.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
#include <unistd.h>

int main (int argc, char *argv[])
{
    int it=0;
    int itmax=50;


    // init MPI and get world_rank and world_size
    int world_rank, world_size;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    // get processor name
    int len;
    char mpi_name[100];
    MPI_Get_processor_name(mpi_name, &len);
    
    printf ("Rank(%d/%d): Start\n", world_rank, world_size);

    // get all processors names
    char local_name[128];
    char global_name[128];
    sprintf(local_name, "%s,", mpi_name);
    
    // shared processors names
    bzero(global_name,128);
    MPI_Allgather(local_name, strlen(local_name), MPI_CHAR, global_name, strlen(local_name), MPI_CHAR, MPI_COMM_WORLD);
                            
    // start loop
    for (; it < itmax; it ++) {
        
        printf("Rank (%d/%d): Iteration= %d, Hello world from: \n\t\t%s\n", world_rank, world_size, it, global_name);

        // simulate compute
        sleep(1);
    }
    printf("Rank (%d/%d): End of loop \n", world_rank, world_size);

    MPI_Finalize();
    
    printf("Rank (%d/%d): End of process %d\n", world_rank, world_size, world_rank);
    if (world_rank == 0) {
        printf("Rank (%d/%d): End of Application\n", world_rank, world_size);
    }

    return 0;
}
