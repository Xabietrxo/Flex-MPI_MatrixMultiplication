/**
 *
 *    Jacobi iterative method
 *
 */
#include <stdio.h>
#include <mpi.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <unistd.h>

void generate_matrix (int dim, double *A, double *B);

int main (int argc, char *argv[])
{
    double *matrixA = NULL;
    double *vectorB = NULL;
    double *vectorX_local = NULL;
    double *vectorX_global = NULL;
    int dim = 6000;
    int ldim = 0;
    int it=0;
    int itmax=1000;

    // book memory for arrays
    matrixA = (double*) calloc (dim*dim, sizeof (double));
    vectorB = (double*) calloc (dim, sizeof (double));
    vectorX_local = (double*) calloc (dim, sizeof (double));
    vectorX_global = (double*) calloc (dim, sizeof (double));

    // init MPI and get world_rank and world_size
    int world_rank, world_size;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    MPI_Comm_size(MPI_COMM_WORLD, &world_size);

    // get processor name
    int len;
    char mpi_name[128];
    MPI_Get_processor_name(mpi_name, &len);

    // compute local dimension for this process
    ldim=dim/world_size;
    
    printf ("Rank(%d/%d): global dimension=%d, local_dimension=%d\n", world_rank, world_size, dim, ldim);

    // Generates the matrix
    if (world_rank == 0) {
        generate_matrix (dim, matrixA, vectorB);
    }
        
    //Bcast matrixes
    MPI_Bcast (matrixA, dim*dim, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Bcast (vectorB, dim, MPI_DOUBLE, 0, MPI_COMM_WORLD);
        
    // start loop
    for (; it < itmax; it ++) {
        
        printf ("Rank(%d/%d): Iteration= %d, global dimension=%d, local_dimension=%d\n", world_rank, world_size, it, dim, ldim);

        //perform the operations
        for (int i=0; i<ldim; i++) {
            int i_global = i+world_rank*ldim;
            double aux = 0.0;
            for (int j=0; j<dim; j++) {
                if (j!=i_global) {
                    aux = aux + matrixA[(i*dim)+j] * vectorX_global[j];
                }
            }
            vectorX_local[i] = (vectorB[i_global]-aux)/matrixA[(i*dim)+i_global];
        }
        
        // gather vector X
        MPI_Allgather (vectorX_local, ldim, MPI_DOUBLE, vectorX_global, ldim,  MPI_DOUBLE, MPI_COMM_WORLD);
    }
    printf("Rank (%d/%d): End of loop \n", world_rank, world_size);

    MPI_Finalize();

    printf("Rank (%d/%d): End of process %d\n", world_rank, world_size, world_rank);
    if (world_rank == 0) {
        printf("Rank (%d/%d): End of Application\n", world_rank, world_size);
    }
    free(matrixA);
    free(vectorB);
    free(vectorX_local);
    free(vectorX_global);

    return 0;
}


// Generate matrix's values
void generate_matrix (int dim, double *A, double *B) {

    for (int i = 0; i < dim; i ++) {
        
        //printf ("B: i=%d\n",i);
        B[i] = (i % 5) + 1;
    
        for (int j = 0; j < dim; j ++){
        
            //A[(i*dim)+j]= 30-60*(rand() / RAND_MAX );  // Original random distribution
            //printf ("A: i=%d, j=%d, (i*dim)+j=%d\n",i,j,(i*dim)+j);

            A[(i*dim)+j]=(double)((i*dim)+j); // For I/O debugging purposes
        }
    }
    
    for (int i = 0; i < dim; i ++) {
        double temp = 0.0;
        for (int j = 0; j < dim; j ++){
            //printf ("A(AGAIN): i=%d, j=%d,  (i*dim)+j=%d\n",i,j,(i*dim)+j);
            temp = temp + A[(i*dim)+j];
        }
        //printf ("A(----): i=%d, (i*dim)+i=%d\n",i, (i*dim)+i);
        A[(i*dim)+i] = temp + dim;
    }
}
