#!/bin/bash

while true; do 
    clear
    echo ----- SLURM JOBS -------
    echo
    squeue 
    echo 
    echo ----- SLURM STEPS -------
    echo
    squeue -s
    echo 
    echo ----- OUTPUT -------
    echo
    tail -n 20 $(ls -t *.out | head -1)
    sleep 1 
done
