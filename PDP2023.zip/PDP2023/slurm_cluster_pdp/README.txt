- Open a shell terminal and create the docker cluster using the script
	> ./launch-slurm-cluster.sh -n 3 -c 3 -d

——————————————

- Open a docker terminal on slurm-node-1 
     > docker exec -it slurm-node-1-1 /bin/bash

- Start the ic server on that terminal
    > icc_server

——————————————

- Open another docker terminal on slurm-node-1 
      > docker exec -it slurm-node-1-1 /bin/bash

- Go to example directory
      > cd /home/admin/ic_examples

- compile all the examples 
	> make

- go back to home directory
	> cd 

- Start any of the three examples 
     >  sbatch /home/admin/ic_examples/reconf_client.sh
			OR
     >  sbatch /home/admin/ic_examples/spawn.sh
			OR
     >  sbatch /home/admin/ic_examples/jacobi_IO.sbatch

- Check periodically the state of slurm cluster (both jobs and steps)
	> squeue; squeue -s

> Once finish edit output and errors files (Ex. job 1)
	> vim slurm-1.out
	> vim slurm-1.err

test squeue peridically
> while true; do squeue; squeue -s; sleep 1; done

Notes:

Compilation and instalation of FlexMPI and ic_examples

node 1:
cd FlexMPI/; HOME=/home/admin make; sudo cp /home/admin/FlexMPI/lib/* /usr/local/lib; sudo cp /home/admin/FlexMPI/include/* /usr/local/include; sudo ldconfig; cd

cd ic_examples; make clean; make; cd ..

node 2 and ....
sudo cp /home/admin/FlexMPI/lib/* /usr/local/lib/; top

node1: server ic
icc_server

node1: application launch
sbatch /home/admin/ic_examples/m_wacomm1_adm.sbatch; while true; do squeue; squeue -s; sleep 1; done


NOTES: erase docker virtual machine to clean it up.
	- Stop docker desktop
	- rm /Users/jfernand/Library/Containers/com.docker.docker/Data/vms/0/data/Docker.raw
	- start Docker Desktop
