#!/bin/bash
cd /home/shared-tmp/admin
sudo cp -a .bash_logout .bashrc .profile .ssh bin /home/admin
cd /home/shared-tmp/user
sudo cp -a .bash_logout .bashrc .profile .ssh bin /home/user
cd /home/shared-tmp/coord
sudo cp -a .bash_logout .bashrc .profile .ssh bin /home/coord
cd /home/admin

#Compile ic framework
cd /home/admin

#tar zxvf shared/ic_mod.tgz
#tar zxvf shared/ic_2022-10-18.tgz
#tar zxvf shared/ic_2022-12-08-1.tgz
#tar zxvf shared/ic_2023_02_24.tgz
tar zxvf shared/ic_$(uname -m)_2023-03-01.tgz

#cd /home/admin/ic
#make all PKG_CONFIG_PATH=/usr/local/lib/pkgconfig
#sleep 10
#pwd > /tmp/begin_ic_install
#sudo make install &> /tmp/ic_install.txt
#pwd > /tmp/end_ic_install
sudo cp /home/admin/ic/bin/* /usr/local/bin
sudo cp /home/admin/ic/lib/* /usr/local/lib
sudo cp /home/admin/ic/include/* /usr/local/include
sudo ldconfig


#Compile FlexMPI framework
cd /home/admin
#tar zxvf shared/FlexMPI.tgz
#tar zxvf shared/FlexMPI_2022_10_24-noMonitorError.tgz
#tar zxvf shared/FlexMPI_2022_12_08-4.tgz #good one
#tar zxvf shared/FlexMPI_2022_12_08-8.tgz
#tar zxvf shared/FlexMPI_2022_12_08-11.tgz
#tar zxvf shared/FlexMPI_2023_01_24.tgz
#tar zxvf shared/FlexMPI_2023_01_24.tgz
#tar zxvf shared/FlexMPI_2023_01_24-1.tgz
#tar zxvf shared/FlexMPI_2023_01_25.tgz
#tar zxvf shared/FlexMPI_2023_02_01.tgz
#tar zxvf shared/FlexMPI_2023_02_24.tgz
#tar zxvf shared/FlexMPI_2023_02_24-1.tgz
#tar zxvf shared/FlexMPI_2023_02_24-2.tgz
#tar zxvf shared/FlexMPI_2023_02_24-3.tgz
#tar zxvf shared/FlexMPI_fortran_ok.tgz
#tar zxvf shared/FlexMPI_2023_03_1.tgz
tar zxvf shared/FlexMPI_$(uname -m)_2023-03-01.tgz

sudo cp /home/admin/FlexMPI/lib/* /usr/local/lib
sudo cp /home/admin/FlexMPI/include/* /usr/local/include
sudo ldconfig


#cd /home/admin/FlexMPI
#cp Makefile.bak Makefile
#cp controller/Makefile.bak controller/Makefile
#cp examples/Makefile.bak examples/Makefile
#cp examples/EpiGraphFlexMPI/Makefile.bak examples/EpiGraphFlexMPI/Makefile
#
#cd /home/admin/FlexMPI/scripts
#cp Execute1.sh.bak Execute1.sh && \
#sed -i "s/\$HOME\/LIBS\/mpich\/bin\/mpiexec/mpiexec/g" Execute1.sh && \
#cp Lanza_CG.sh.bak Lanza_CG.sh && \
#sed -i "s/\${MPIPATH}mpiexec/mpiexec/g" Lanza_CG.sh && \
#cp Lanza_Epigraph.sh.bak Lanza_Epigraph.sh && \
#sed -i "s/\$MPIPATH\/mpiexec/mpiexec/g" Lanza_Epigraph.sh && \
#cp Lanza_Jacobi_IO.sh.bak Lanza_Jacobi_IO.sh && \
#sed -i "s/\${MPIPATH}mpiexec/mpiexec/g" Lanza_Jacobi_IO.sh
#
#cd /home/admin/FlexMPI
#HOME=/home/admin make
#sleep 5
#cd /home/admin/FlexMPI/examples
#HOME=/home/admin make
#sleep 5
#cd /home/admin/FlexMPI/examples/EpiGraphFlexMPI
#HOME=/home/admin make
#sleep 5
#cd /home/admin/FlexMPI/controller
#HOME=/home/admin make || echo "FALTA FICHERO workloadgen.c"
#sleep 5

#cd /home/admin/
#chmod +x /home/admin/FlexMPI/scripts/*.sh
#
##install FlexMPI
#sudo cp /home/admin/FlexMPI/lib/* /usr/local/lib
#sudo cp /home/admin/FlexMPI/include/* /usr/local/include
#sudo cp /home/admin/FlexMPI/controller/controller /usr/local/bin
##sudo bash -c  'echo "/opt/FlexMPI/lib" > /etc/ld.so.conf.d/flexmpi.conf'
#sudo ldconfig

#change sh for bash
sudo bash &> /dev/null << EOF
    echo -e '#!/bin/bash\n/bin/bash "\$@"' > /bin/sh.bash
    exit
EOF
sudo chmod +x /bin/sh.bash
sudo rm /bin/sh
sudo ln -s /bin/sh.bash /bin/sh

#load library path
sudo ldconfig

#Extract and make ic_examples
cd /home/admin
#tar zxvf shared/ic_examples.tgz
#tar zxvf shared/ic_examples_2022-11-10-2.tgz
#tar zxvf shared/ic_examples_2022-11-10-3.tgz
#tar zxvf shared/ic_examples_2022-11-10-4.tgz
#tar zxvf shared/ic_examples_2023_01_24.tgz
#tar zxvf shared/ic_examples_2023_02_24.tgz
#tar zxvf shared/ic_examples_2023_02_25.tgz

#cd ic_examples
#make

#Extract and make tutorial_examples
cd /home/admin
tar zxvf shared/tutorial_examples_2023-03-01-2.tgz

cd tutorial_examples
make

cd /home/admin/
#sudo hostnamectl set-hostname ubuntu-1
#get HOSTIP and HOSTNAME variable
export HOSTIP=$(getent hosts $(hostname) | awk '{print $1}')
#export HOSTNAME=$(nslookup $HOSTIP | head -1 | awk '{split($4,a,"."); print a[1]}')
export HOSTNAME=$(hostname)
export HOSTPATTERN=$(echo ${HOSTNAME} | awk -F '-' '{for(i=1;i<=(NF-2);i++) printf("%s-",$i); printf("%s-",$i)}')
touch /tmp/pru
touch /tmp/${HOSTIP}
touch /tmp/${HOSTNAME}
touch /tmp/${HOSTPATTERN}

#set slurm for the number of nodes and CPUs
export SLURM_NUM_NODES=0
getent hosts ${HOSTPATTERN}$((${SLURM_NUM_NODES} + 1))
while [ "$?" == "0" ]; do
    export SLURM_NUM_NODES=$((${SLURM_NUM_NODES} + 1));
    getent hosts ${HOSTPATTERN}$((${SLURM_NUM_NODES} + 1))
done
touch /tmp/SLURM_NUM_NODES-${SLURM_NUM_NODES}

if [ -v ${SLURM_CPUS_ON_NODE} ]; then
    export SLURM_CPUS_ON_NODE=1;
fi
touch /tmp/SLURM_CPUS_ON_NODE-${SLURM_CPUS_ON_NODE}

sudo sed -i "s/REPLACE_MASTER/${HOSTPATTERN}1/g" /etc/slurm/slurm.conf
sudo sed -i "s/REPLACE_PATTERN/${HOSTPATTERN}/g" /etc/slurm/slurm.conf
sudo sed -i "s/REPLACE_NODES/${SLURM_NUM_NODES}/g" /etc/slurm/slurm.conf
sudo sed -i "s/REPLACE_CPUS/${SLURM_CPUS_ON_NODE}/g" /etc/slurm/slurm.conf

#set munge service
#sudo systemctl enable munge
#sudo systemctl start munge
sudo service munge start

# set slurm node service
#sudo systemctl enable slurmd
#sudo systemctl start slurmd
sudo service slurmd start

#init ssh server and non-password conection
sudo service ssh start
touch /tmp/begin_ssh
for USER in admin user coord; do
    for NODE in $(seq 1 ${SLURM_NUM_NODES}); do
        sudo su --command="ssh-keyscan -t ecdsa ${HOSTPATTERN}${NODE} >> /home/${USER}/.ssh/known_hosts" ${USER}
        while [ "$?" != "0" ]; do
            sleep 1
            sudo su --command="ssh-keyscan -t ecdsa ${HOSTPATTERN}${NODE} >> /home/${USER}/.ssh/known_hosts" ${USER}
        done
    done
done
touch /tmp/end_ssh


#run redis server and cluster
echo never | sudo tee /sys/kernel/mm/transparent_hugepage/enabled
sudo sysctl -w net.core.somaxconn=65535
#echo "vm.overcommit_memory=1" | sudo tee -a /etc/sysctl.conf
#sudo systemctl enable redis-server
#sudo systemctl start redis-server
sudo service redis-server start
#check if master or normal node


# launch NFS server and clientes
#if [ "${HOSTNAME}" == "${HOSTPATTERN}1" ]; then
#    # configure nfs exports
#    export EXPORT_USER="/home/user"
#    export EXPORT_ADMIN="/home/admin"
#    export EXPORT_COORD="/home/coord"
#    mkdir -p /tmp${EXPORT_USER}-${HOSTPATTERN}
#    for NODE in $(seq 1 ${SLURM_NUM_NODES}); do
#        export EXPORT_USER="${EXPORT_USER} ${HOSTPATTERN}${NODE}(rw,sync,no_root_squash,no_subtree_check)"
#        export EXPORT_ADMIN="${EXPORT_ADMIN} ${HOSTPATTERN}${NODE}(rw,sync,no_root_squash,no_subtree_check)"
#        export EXPORT_COORD="${EXPORT_COORD} ${HOSTPATTERN}${NODE}(rw,sync,no_root_squash,no_subtree_check)"
#    done
#    echo -e "\n${EXPORT_USER}\n${EXPORT_ADMIN}\n${EXPORT_COORD}\n" > /tmp/tmp1
#    sudo bash -c 'cat /tmp/tmp1 >> /etc/exports'
#    sudo service nfs-kernel-server start
#else
#    sleep 5
#    echo -e "\n/home /etc/auto.home --timeout=300" > /tmp/tmp1
#    sudo bash -c 'cat /tmp/tmp1 >> /etc/auto.master'
#    echo -e "* -rw,soft,timeo=5,intr,rsize=8192,wsize=8192 ${HOSTPATTERN}1:/home/&" > /tmp/tmp1
#    sudo bash -c 'cat /tmp/tmp1 > /etc/auto.home'
#    sudo service autofs start
#fi
#
#---------- END SLAVE SECTION ------------
#
if [ "${HOSTNAME}" != "${HOSTPATTERN}1" ]; then
    touch /tmp/no_master
    tail -f /dev/null
fi

#
#---------- BEGIN MASTER ONLY SECTION------------
#
#set munge service
#sudo systemctl enable mysql
#sudo systemctl start mysql
sudo service mysql start

#secure mariadb database
sudo mysql_secure_installation << EOF

n
y
y
y
y
EOF

#set admin as mariadb root
sudo mariadb << EOF
    GRANT ALL ON *.* TO 'admin'@'localhost' IDENTIFIED BY 'admin'  WITH GRANT OPTION;
    FLUSH PRIVILEGES;
    exit
EOF

#set slurm database on mariadb
sudo mysql << EOF
    create database slurm_acct_db;
    create user 'slurm'@'localhost';
    set password for 'slurm'@'localhost' = password('slurm');
    grant usage on *.* to 'slurm'@'localhost';
    grant all privileges on slurm_acct_db.* to 'slurm'@'localhost';
    flush privileges;
EOF

#set slurm database service
#sudo systemctl enable slurmdbd
#sudo systemctl start slurmdbd
sudo service slurmdbd start
sleep 2

#Configure slurm database
sudo sacctmgr -i add cluster cluster
#sudo sacctmgr list cluster
sudo sacctmgr -i add account malleable description "Malleable Account" Organization=Malleable
sudo sacctmgr -i add account static description "Static Account" Organization=Static
#sudo sacctmgr list account
sudo sacctmgr -i create user admin account=malleable defaultaccount=malleable adminlevel=Operator
sudo sacctmgr -i create user user account=static defaultaccount=static adminlevel=None
sudo sacctmgr -i create user coord account=static defaultaccount=static adminlevel=None
sudo sacctmgr -i create coordinator account=static names=coord
#sudo sacctmgr list user

#set slurm control service
#sudo systemctl enable slurmctld
#sudo systemctl start slurmctld
sudo service slurmctld start

#set redis cluster
export REDIS_CLUSTER_HOSTS=""
for NODE in $(seq 1 ${SLURM_NUM_NODES}); do
    DONE=$(ssh ${HOSTPATTERN}${NODE} "sudo service redis-server status" | awk '{print $4}')
    while [ "$DONE" != "running" ]; do
        sleep 1
        DONE=$(ssh ${HOSTPATTERN}${NODE} "sudo service redis-server status" | awk '{print $4}')
    done
    export REDIS_CLUSTER_HOSTS="${REDIS_CLUSTER_HOSTS}$(getent hosts ${HOSTPATTERN}${NODE} | awk '{print $1}'):6379 "
done
sudo redis-cli --cluster create  ${REDIS_CLUSTER_HOSTS} << EOF
yes
EOF
#redis-cli -c -h slurm-node-1 -p 6379
# > CLUSTER NODES

#
#---------- END MASTER ------------
#

tail -f /dev/null
